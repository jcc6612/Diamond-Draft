# Diamond Draft: The 162-0 Challenge — Copilot Instructions

Follow these non-negotiable product, visual, and engineering rules on every change:

1. **Real Historical Players Only**: Never generate synthetic, fictional, or filler players. Every entry in `data/historical-db.js / scripts/build_lahman_db.py` must be a real MLB player who actually played for that exact franchise during that exact decade (sourced from SABR Lahman, Retrosheet, Baseball-Reference, or FanGraphs).
2. **Franchise + Era Integrity**: Only players who appeared for the rolled franchise during the rolled decade may enter that scouting pool. Target 20–50+ players per pool (meaningful position players + 10 SP + 10 RP whenever possible).
3. **Archival Scouting Dossiers & Zero Visible Ratings**: Present players as scouting dossiers (Name, Franchise, Position, Years/Seasons with franchise, Team-Era stats, Period Awards). NEVER display OVR, Overall Rating, Team OVR, Legend Score, or Draft Score anywhere in the UI. Keep all calculations internal inside `engine/game-engine.js`.
4. **Realistic Top-Down Ballpark & Position Separation**: Keep the top-down stadium (`assets/ballpark.jpg`) clean with zero diagram arches, curved bands, or whiteboard lines. Place ONLY defensive positions on the field (Quick Draft: 2 OF, 2 IF, 1 SP). Keep DH and RP strictly inside the off-field Dugout & Bullpen panel.
5. **Black Diamond Identity**: Matte black (`#0B0D10`), graphite (`#12151B`), charcoal (`#181C24`), brushed silver (`#B5C0D0`), diamond white (`#F4F6F9`). Use team colors strictly as accents. Avoid neon effects, bright gradients, or SaaS dashboard styling.
6. **Simulation Variance & Win Targets**: Preserve baseball randomness and calibrated win bands (Weak 60–80, Average 80–95, Great 95–105, Elite 105–115, Historic 115–125, Dream Team 125–140, Perfect 162–0 extremely rare).
7. **Unified Engine Across All 7 Modes**: Quick Draft, Full Team, Hall of Fame, Franchise Mode, Decade Mode, Blind Draft, and Ironman Mode must share one draft and simulation engine.

8. **Zero Manual Hardcoding**: Never re-introduce hardcoded `RAW_VAULT` arrays. Expand coverage via `scripts/build_lahman_db.py` or `HistoricalDatabase.loadRecords()` / `ingestLahmanCsvBundle()`. Never curate, rank, or trim franchise-era scouting pools.

9. **One-Time Franchise + Era Per Run & Immediate Re-Roll**: Track completed chapters in `usedPools` (`Set` of `${franchiseId}__${decade}`). Immediately roll a new unused Franchise + Era after every draft pick. Rerolls must never restore a used pool.
